"# cpdp_multithread_calculator" 

first clone the project

next  go to the individual folders 

cd backend

npm install

npm start


After the installation is done. the url can be open in browser **http://localhost:3000/** 

and for frontend

cd react-calculator

npm install

npm start
After the installation is done. the backend is running at **http://localhost:4001/**
